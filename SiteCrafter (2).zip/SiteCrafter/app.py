import os
import asyncio
import pandas as pd
import threading
from flask import Flask, request, render_template_string, flash, redirect, url_for, session, jsonify
from telethon import TelegramClient
from telethon.errors import SessionPasswordNeededError, PhoneCodeInvalidError, FloodWaitError
from telethon.tl.types import InputPeerUser
import secrets  # For secure session naming

app = Flask(__name__)
app.secret_key = os.environ.get('SESSION_SECRET', secrets.token_hex(16))

# Get credentials from environment variables (get from my.telegram.org)
API_ID_STR = os.environ.get('TELEGRAM_API_ID', '').strip()
API_HASH = os.environ.get('TELEGRAM_API_HASH', '').strip()

# Validate required credentials first, before converting
if not API_ID_STR or not API_HASH:
    raise ValueError("TELEGRAM_API_ID and TELEGRAM_API_HASH environment variables are required")

try:
    API_ID = int(API_ID_STR)  # Convert after validation
except ValueError:
    raise ValueError("TELEGRAM_API_ID must be a valid integer")

# Phone number will be provided by user

# Authentication state (no global client)
auth_state = {
    'code_requested': False,
    'is_authenticated': False,
    'phone_code_hash': None,
    'phone_number': None
}

# Global state for message sending control
sending_state = {
    'is_sending': False,
    'should_stop': False,
    'current_message': 0,
    'total_messages': 0,
    'current_number': ''
}

# Shared CSS styles
SHARED_STYLES = """
        body {
            margin: 0;
            padding: 20px;
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #0c0c3b, #1a1a5e, #0f0f4f); /* Blue anime night sky gradient */
            background-size: 400% 400%;
            animation: animeWave 15s ease infinite; /* Subtle anime-style wave animation */
            color: white;
            min-height: 100vh;
        }
        @keyframes animeWave {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }
        .container { max-width: 600px; margin: 0 auto; background: rgba(0,0,0,0.5); padding: 20px; border-radius: 10px; }
        input, textarea, button { width: 100%; padding: 10px; margin: 10px 0; border: none; border-radius: 5px; }
        textarea { height: 100px; }
        button { background: #4a90e2; color: white; cursor: pointer; }
        button:hover { background: #357abd; }
        .error { color: #ff6b6b; }
        .success { color: #51cf66; }
        .nav-link { display: inline-block; padding: 10px 15px; margin: 5px; background: #2c2c54; border-radius: 5px; text-decoration: none; color: white; }
        .nav-link:hover { background: #40407a; }
        .stop-button { background: #e74c3c !important; margin-top: 10px; }
        .stop-button:hover { background: #c0392b !important; }
        .sending-status { padding: 10px; margin: 10px 0; border-radius: 5px; background: rgba(255,255,255,0.1); display: none; }
        .progress-info { color: #51cf66; font-weight: bold; margin: 5px 0; }
"""

# Authentication page template
AUTH_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Telegram Authentication</title>
    <style>""" + SHARED_STYLES + """</style>
</head>
<body>
    <div class="container">
        <h1>Telegram File Sender</h1>
        <p>Please authenticate with Telegram to continue</p>
        
        {% with messages = get_flashed_messages(with_categories=true) %}
            {% if messages %}
                {% for category, message in messages %}
                    <p class="{{ category }}">{{ message }}</p>
                {% endfor %}
            {% endif %}
        {% endwith %}
        
        {% if not code_requested %}
            <form method="POST" action="/request_code">
                <h2>Connect to Telegram</h2>
                <input type="text" name="phone" placeholder="Enter phone number with country code (e.g., +1234567890)" required>
                <button type="submit">Request Login Code</button>
            </form>
        {% else %}
            <form method="POST" action="/login">
                <h2>Enter Telegram Code</h2>
                <p>Code sent to: {{ phone_number }}</p>
                <input type="text" name="code" placeholder="Enter code from Telegram app" required>
                <button type="submit">Login</button>
            </form>
        {% endif %}
    </div>
</body>
</html>
"""

# Dashboard page template  
DASHBOARD_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Telegram File Sender - Dashboard</title>
    <style>""" + SHARED_STYLES + """</style>
</head>
<body>
    <div class="container">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <h1>File Sender Dashboard</h1>
            <a href="/logout" class="nav-link">Logout</a>
        </div>
        
        {% with messages = get_flashed_messages(with_categories=true) %}
            {% if messages %}
                {% for category, message in messages %}
                    <p class="{{ category }}">{{ message }}</p>
                {% endfor %}
            {% endif %}
        {% endwith %}
        
        <form method="POST" enctype="multipart/form-data" action="/upload">
            <h2>Upload CSV or Enter Data</h2>
            <label>CSV File:</label>
            <input type="file" name="file" accept=".csv">
            <label>Or Enter Manual Data:</label>
            <textarea name="manual_data" placeholder="Enter data line by line (one per line)"></textarea>
            <label>Recipient:</label>
            <input type="text" name="recipient" placeholder="@username or @botname" required>
            
            <label>Send Mode:</label>
            <div style="margin: 10px 0;">
                <input type="radio" id="columns" name="send_mode" value="columns" checked>
                <label for="columns" style="display: inline; margin-left: 5px; margin-right: 20px;">Column by Column (each column separately)</label>
                <input type="radio" id="rows" name="send_mode" value="rows">
                <label for="rows" style="display: inline; margin-left: 5px;">Row by Row (combine columns per row)</label>
            </div>
            
            <button type="submit" id="sendButton">Send to Recipient</button>
            
            <div id="sendingStatus" class="sending-status">
                <p id="statusText">Sending messages...</p>
                <div class="progress-info" id="progressInfo">Progress: 0/0</div>
                <button type="button" id="stopButton" class="stop-button">Stop Sending</button>
            </div>
        </form>
    </div>
    
    <script>
        let sendingInterval;
        
        // Start polling for sending status when page loads (in case we're already sending)
        window.addEventListener('load', function() {
            checkSendingStatusOnce();
        });
        
        document.getElementById('stopButton').addEventListener('click', function() {
            fetch('/stop', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'}
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    document.getElementById('statusText').textContent = 'Stopping...';
                    document.getElementById('stopButton').disabled = true;
                }
            })
            .catch(error => console.error('Error:', error));
        });
        
        function checkSendingStatus() {
            fetch('/sending_status')
            .then(response => response.json())
            .then(data => {
                if (data.is_sending) {
                    // Currently sending - show stop button and update progress
                    document.getElementById('sendingStatus').style.display = 'block';
                    document.getElementById('sendButton').disabled = true;
                    document.getElementById('progressInfo').textContent = 
                        `Progress: ${data.current_message}/${data.total_messages} - Current: ${data.current_number}`;
                    if (!sendingInterval) {
                        sendingInterval = setInterval(checkSendingStatus, 1000);
                    }
                } else {
                    // Not sending - hide stop button
                    if (sendingInterval) {
                        clearInterval(sendingInterval);
                        sendingInterval = null;
                    }
                    document.getElementById('sendingStatus').style.display = 'none';
                    document.getElementById('sendButton').disabled = false;
                    document.getElementById('stopButton').disabled = false;
                }
            })
            .catch(error => console.error('Error:', error));
        }
        
        function checkSendingStatusOnce() {
            fetch('/sending_status')
            .then(response => response.json())
            .then(data => {
                if (data.is_sending) {
                    // Currently sending - show stop button and start polling
                    document.getElementById('sendingStatus').style.display = 'block';
                    document.getElementById('sendButton').disabled = true;
                    document.getElementById('progressInfo').textContent = 
                        `Progress: ${data.current_message}/${data.total_messages} - Current: ${data.current_number}`;
                    sendingInterval = setInterval(checkSendingStatus, 1000);
                }
            })
            .catch(error => console.error('Error:', error));
        }
    </script>
</body>
</html>
"""

# Remove the global client function - we'll create clients per request

@app.route('/', methods=['GET'])
def index():
    # If already authenticated, redirect to dashboard
    if auth_state['is_authenticated']:
        return redirect(url_for('dashboard'))
    
    return render_template_string(AUTH_TEMPLATE, 
                                code_requested=auth_state['code_requested'],
                                phone_number=auth_state.get('phone_number', ''))

@app.route('/request_code', methods=['POST'])
def request_code():
    """Request authentication code from Telegram"""
    phone = request.form['phone'].strip()
    
    if not phone:
        flash('Please enter a phone number.', 'error')
        return redirect(url_for('index'))
    
    # Store phone number in auth state
    auth_state['phone_number'] = phone
    
    try:
        async def _request_code():
            # Create client with unique session per phone number
            import hashlib
            session_name = f'session_{hashlib.md5(phone.encode()).hexdigest()[:8]}'
            client = TelegramClient(session_name, API_ID, API_HASH)
            try:
                await client.connect()
                if not await client.is_user_authorized():
                    result = await client.send_code_request(phone)
                    auth_state['phone_code_hash'] = result.phone_code_hash
                    auth_state['code_requested'] = True
                    auth_state['session_name'] = session_name
                    return True
                else:
                    auth_state['is_authenticated'] = True
                    return False
            finally:
                client.disconnect()
        
        code_requested = asyncio.run(_request_code())
        
        if code_requested:
            flash('Login code sent to your Telegram app!', 'success')
        else:
            flash('Already authenticated!', 'success')
    except Exception as e:
        flash(f'Error requesting code: {str(e)}', 'error')
        auth_state['code_requested'] = False  # Reset on error
    
    return redirect(url_for('index'))

@app.route('/login', methods=['POST'])
def login():
    """Complete authentication with code from Telegram"""
    code = request.form['code']
    try:
        async def _login():
            phone = auth_state.get('phone_number')
            if not phone:
                return 'error:Phone number not found. Please start over.'
            
            # Use the same session that was created during code request
            session_name = auth_state.get('session_name', 'web_session')
            client = TelegramClient(session_name, API_ID, API_HASH)
            try:
                await client.connect()
                phone_code_hash = auth_state.get('phone_code_hash')
                if not phone_code_hash:
                    return 'error:Phone code hash not found. Please restart the process.'
                
                # Clean the code (remove spaces, dashes, etc.)
                clean_code = ''.join(filter(str.isdigit, code))
                if len(clean_code) != 5:
                    return 'error:Code must be exactly 5 digits. Please check and try again.'
                
                await client.sign_in(phone, clean_code, phone_code_hash=phone_code_hash)
                auth_state['is_authenticated'] = True
                me = await client.get_me()
                name = getattr(me, 'first_name', 'User')
                return f'Logged in as {name}!'
            except SessionPasswordNeededError:
                return 'error:2FA password needed. Please disable 2FA or extend application to handle it.'
            except PhoneCodeInvalidError:
                return 'error:Invalid code. Please check the code from your Telegram app and try again.'
            except Exception as e:
                return f'error:Authentication failed: {str(e)}'
            finally:
                client.disconnect()
        
        result = asyncio.run(_login())
        
        if result.startswith('error:'):
            flash(result[6:], 'error')
            return redirect(url_for('index'))
        else:
            flash(result, 'success')
            return redirect(url_for('dashboard'))
    except Exception as e:
        flash(f'Login error: {str(e)}', 'error')
        return redirect(url_for('index'))

@app.route('/dashboard', methods=['GET'])
def dashboard():
    """Dashboard page for authenticated users"""
    if not auth_state['is_authenticated']:
        flash('Please login first.', 'error')
        return redirect(url_for('index'))
    
    return render_template_string(DASHBOARD_TEMPLATE)

@app.route('/logout', methods=['GET'])
def logout():
    """Logout and clear authentication state"""
    auth_state['is_authenticated'] = False
    auth_state['code_requested'] = False
    auth_state['phone_code_hash'] = None
    auth_state['phone_number'] = None
    flash('Logged out successfully!', 'success')
    return redirect(url_for('index'))

@app.route('/stop', methods=['POST'])
def stop_sending():
    """Stop the current message sending process"""
    if not auth_state['is_authenticated']:
        return jsonify({'status': 'error', 'message': 'Not authenticated'}), 401
    
    sending_state['should_stop'] = True
    return jsonify({'status': 'success', 'message': 'Stop signal sent'})

@app.route('/sending_status', methods=['GET'])
def get_sending_status():
    """Get current sending status"""
    if not auth_state['is_authenticated']:
        return jsonify({'status': 'error', 'message': 'Not authenticated'}), 401
    
    return jsonify({
        'is_sending': sending_state['is_sending'],
        'should_stop': sending_state['should_stop'],
        'current_message': sending_state['current_message'],
        'total_messages': sending_state['total_messages'],
        'current_number': sending_state['current_number']
    })

@app.route('/upload', methods=['POST'])
def upload():
    """Handle CSV upload or manual data input and send to Telegram recipient"""
    if not auth_state['is_authenticated']:
        flash('Please login first.', 'error')
        return redirect(url_for('index'))
    
    file = request.files.get('file')
    manual_data = request.form.get('manual_data', '').strip()
    recipient = request.form['recipient'].strip()
    send_mode = request.form.get('send_mode', 'columns').strip()  # Get send mode
    
    # Validate input: Ensure either file or manual data is provided
    if not (file and file.filename) and not manual_data:
        flash('Please provide either a CSV file or manual data.', 'error')
        return redirect(url_for('dashboard'))
    
    # Start background sending and return immediately to show stop button
    def background_send():
        sending_state['should_stop'] = False
        sending_state['is_sending'] = True
        
        async def _upload():
            # Use the same session that was used for authentication
            session_name = auth_state.get('session_name', 'web_session')
            client = TelegramClient(session_name, API_ID, API_HASH)
            try:
                await client.connect()
                
                # Verify client is still authorized
                if not await client.is_user_authorized():
                    auth_state['is_authenticated'] = False
                    return 'error:Session expired. Please login again.'
                
                # Resolve recipient (user or bot)
                try:
                    entity = await client.get_entity(recipient)
                except Exception:
                    return f'error:Could not find recipient "{recipient}". Please check the username.'
                
                # Handle CSV file
                if file and file.filename:
                    if not file.filename.endswith('.csv'):
                        return 'error:File must be a CSV file.'
                    try:
                        df = pd.read_csv(file.stream)
                        # Clean up data for better messaging
                        # Remove auto-generated index columns and empty columns
                        df = df.loc[:, ~df.columns.str.startswith('Unnamed:')]
                        df = df.dropna(axis=1, how='all')  # Remove completely empty columns
                    except Exception:
                        return 'error:Invalid CSV file. Please check the format.'
                else:
                    # Handle manual input (treat as single-column CSV)
                    if not manual_data:
                        return 'error:Manual data cannot be empty.'
                    
                    # Parse manual input - split by newlines only
                    if '\n' in manual_data:
                        # Split by newlines if present
                        data = [x.strip() for x in manual_data.split('\n') if x.strip()]
                    else:
                        # If no newlines, treat entire input as one message
                        data = [manual_data.strip()]
                    
                    df = pd.DataFrame({'Manual Input': data})
                
                # Send data based on selected mode
                if send_mode == 'rows':
                    # Row by row: Send each row combining all columns
                    await send_row_data(client, entity, df)
                    return 'success:Data sent successfully! All rows processed.'
                else:
                    # Column by column: Send each column's data separately (default)
                    for col in df.columns:
                        await send_column_data(client, entity, df[col], col)
                    return 'success:Data sent successfully! All columns processed.'
            finally:
                client.disconnect()
        
        try:
            result = asyncio.run(_upload())
            print(f"Sending completed with result: {result}")
        except Exception as e:
            print(f"Background sending error: {str(e)}")
        finally:
            # Always reset sending state when done
            sending_state['is_sending'] = False
            sending_state['should_stop'] = False
    
    # Start the background thread
    thread = threading.Thread(target=background_send)
    thread.daemon = True
    thread.start()
    
    flash('Message sending started! You can stop it anytime using the stop button.', 'success')
    return redirect(url_for('dashboard'))

# Helper: Send column data line by line (one complete item per message)
async def send_column_data(client, entity, data_series, col_name):
    """Send each data item as one complete message, one by one"""
    try:
        await client.send_message(entity, f'--- Column: {col_name} ---')  # Header
        print(f"Starting to send {len(data_series)} items from column '{col_name}'")
        
        for i, value in enumerate(data_series, 1):
            # Check if stop signal was sent
            if sending_state['should_stop']:
                print("Stop signal received, halting column sending...")
                await client.send_message(entity, '--- Sending stopped by user ---')
                return
                
            # Update progress
            sending_state['current_message'] = i
            sending_state['total_messages'] = len(data_series)
                
            # Better numeric formatting - avoid .0 for integers (consistent with row mode)
            if pd.isna(value):
                continue  # Skip NaN values
            elif (isinstance(value, (float, int)) or hasattr(value, 'dtype')) and str(value).replace('.0', '').replace('-', '').isdigit():
                # Handle both Python float/int and numpy numeric types
                try:
                    if float(value) == int(float(value)):
                        value_str = str(int(float(value)))  # Convert 1.0 to 1
                    else:
                        value_str = str(value).strip()
                except (ValueError, OverflowError):
                    value_str = str(value).strip()
            else:
                value_str = str(value).strip()
            
            if value_str:  # Only send non-empty values
                # Update current number being sent
                sending_state['current_number'] = value_str
                try:
                    print(f"Sending message {i}: '{value_str}'")
                    await client.send_message(entity, value_str)  # Send complete value as one message
                    print(f"Message {i} sent successfully, waiting 1 second...")
                    await asyncio.sleep(1.0)  # Increased delay to make sequential sending more obvious
                except FloodWaitError as e:
                    # Handle rate limiting by waiting the required time
                    print(f"Rate limit hit, waiting {e.seconds + 1} seconds...")
                    await asyncio.sleep(e.seconds + 1)
                    await client.send_message(entity, value_str)  # Retry after waiting
                    print(f"Message {i} sent after rate limit wait")
                except Exception as e:
                    # Log and continue with next item if individual message fails
                    print(f"Failed to send item {i} '{value_str}': {e}")
            else:
                print(f"Skipping empty/NaN value at position {i}")
        
        await client.send_message(entity, '--- End Column ---')  # Footer
        print(f"Finished sending all items from column '{col_name}'")
    except Exception as e:
        print(f"Failed to send column '{col_name}': {e}")
        raise

# Helper: Send data row by row (one message per row combining all columns)
async def send_row_data(client, entity, df, delay=1.0):
    """Send each row as one message combining all columns"""
    try:
        total_rows = len(df)
        await client.send_message(entity, f'--- Sending {total_rows} rows ---')  # Header
        print(f"Starting to send {total_rows} rows")
        
        for i, (index, row) in enumerate(df.iterrows(), 1):
            # Check if stop signal was sent
            if sending_state['should_stop']:
                print("Stop signal received, halting row sending...")
                await client.send_message(entity, '--- Sending stopped by user ---')
                return
                
            # Update progress
            sending_state['current_message'] = i
            sending_state['total_messages'] = total_rows
                
            # Build message combining all non-empty columns for this row
            row_parts = []
            for col_name, value in row.items():
                # Better numeric formatting - avoid .0 for integers (handle numpy types)
                if pd.isna(value):
                    continue  # Skip NaN values
                elif (isinstance(value, (float, int)) or hasattr(value, 'dtype')) and str(value).replace('.0', '').replace('-', '').isdigit():
                    # Handle both Python float/int and numpy numeric types
                    try:
                        if float(value) == int(float(value)):
                            value_str = str(int(float(value)))  # Convert 1.0 to 1
                        else:
                            value_str = str(value).strip()
                    except (ValueError, OverflowError):
                        value_str = str(value).strip()
                else:
                    value_str = str(value).strip()
                
                if value_str:  # Only include non-empty values
                    if len(df.columns) == 1:
                        # For single column, just send the value
                        row_parts.append(value_str)
                    else:
                        # For multiple columns, include column name
                        row_parts.append(f"{col_name}: {value_str}")
            
            if row_parts:  # Only send if there's data
                message = " | ".join(row_parts)
                # Update current number being sent
                sending_state['current_number'] = message
                try:
                    print(f"Sending row {i}/{total_rows}: '{message}'")
                    await client.send_message(entity, message)
                    print(f"Row {i} sent successfully, waiting {delay} seconds...")
                    await asyncio.sleep(delay)
                except FloodWaitError as e:
                    # Handle rate limiting by waiting the required time
                    print(f"Rate limit hit, waiting {e.seconds + 1} seconds...")
                    await asyncio.sleep(e.seconds + 1)
                    await client.send_message(entity, message)  # Retry after waiting
                    print(f"Row {i} sent after rate limit wait")
                except Exception as e:
                    # Log and continue with next row if individual message fails
                    print(f"Failed to send row {i} '{message}': {e}")
            else:
                print(f"Skipping empty row {i}")
        
        await client.send_message(entity, '--- All rows sent ---')  # Footer
        print(f"Finished sending all {total_rows} rows")
    except Exception as e:
        print(f"Failed to send rows: {e}")
        raise

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)