# Overview

This is a Telegram File Sender web application built with Flask that allows users to authenticate with Telegram and send files through the Telegram API. The application provides a web interface for Telegram authentication and file transmission capabilities using the Telethon library for interacting with Telegram's API.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Web Interface**: Single-page Flask application using server-side rendered HTML templates
- **Styling**: Custom CSS with anime-inspired blue gradient background and animations
- **User Flow**: Multi-step authentication process (phone number → verification code → optional 2FA)
- **Session Management**: Flask sessions for maintaining authentication state across requests

## Backend Architecture
- **Web Framework**: Flask-based web server with route handlers for authentication and file operations
- **Async Integration**: Asyncio integration within Flask for handling Telegram's async API calls
- **Authentication Flow**: Multi-step Telegram authentication using phone number and verification codes
- **State Management**: In-memory authentication state tracking with session-based user data
- **File Processing**: Pandas integration for CSV file handling and processing

## Security Model
- **Session Security**: Secure session key generation using secrets module
- **Environment-based Config**: API credentials stored in environment variables
- **No Persistent Sessions**: Authentication state maintained only during active sessions

## API Integration Pattern
- **Telethon Client**: Telegram API client for authentication and message sending
- **Error Handling**: Comprehensive error handling for Telegram API errors (flood wait, invalid codes, etc.)
- **Session Management**: Dynamic Telegram session creation per user authentication

# External Dependencies

## Core Framework Dependencies
- **Flask**: Web application framework for routing and templating
- **Pandas**: Data processing library for CSV file manipulation
- **Asyncio**: Python async/await support for Telegram API integration

## Telegram Integration
- **Telethon**: Primary Telegram API client library
- **Telegram API**: Requires API_ID and API_HASH from my.telegram.org
- **Authentication**: Phone-based authentication with optional 2FA support

## Required Environment Variables
- `TELEGRAM_API_ID`: Telegram API ID (integer, required)
- `TELEGRAM_API_HASH`: Telegram API hash (string, required)
- `SESSION_SECRET`: Flask session secret key (optional, auto-generated if not provided)

## Runtime Requirements
- Environment variables must be configured before application startup
- No external database dependencies (uses in-memory state)
- No external file storage (processes uploaded files in memory)